<?php

namespace XF\AddOn;

/**
 * @deprecated AbstractSetup::checkRequirements() is used instead and this interface will be removed.
 */
interface CheckRequirementsInterface {}